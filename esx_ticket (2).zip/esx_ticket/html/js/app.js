// ====================================================
//  esx_ticket | app.js
// ====================================================

const overlay      = document.getElementById('overlay');
const playerPanel  = document.getElementById('player-panel');
const adminPanel   = document.getElementById('admin-panel');
const ticketList   = document.getElementById('ticket-list');
const ticketDetail = document.getElementById('ticket-detail');
const emptyState   = document.getElementById('empty-state');
const countBadge   = document.getElementById('ticket-count-badge');
const replyBanner  = document.getElementById('reply-banner');

let tickets        = [];
let activeTicketId = null;
let replyTimer     = null;

// ── NUI Events ───────────────────────────────────────
window.addEventListener('message', function(e) {
    const d = e.data;

    if (d.type === 'openPlayer') {
        overlay.classList.add('visible');
        playerPanel.classList.remove('hidden');
        adminPanel.classList.add('hidden');
        document.getElementById('ticket-message').value = '';
        updateCharCount();
    }

    if (d.type === 'openAdmin') {
        tickets = d.tickets || [];
        overlay.classList.add('visible');
        adminPanel.classList.remove('hidden');
        playerPanel.classList.add('hidden');
        showList();
        renderList();
    }

    if (d.type === 'newTicket') {
        tickets.push(d.ticket);
        renderList();
    }

    if (d.type === 'updateTicket') {
        const idx = tickets.findIndex(t => t.id === d.ticket.id);
        if (idx !== -1) tickets[idx] = d.ticket;
        renderList();
        if (activeTicketId === d.ticket.id) renderDetail(d.ticket);
    }

    if (d.type === 'removeTicket') {
        tickets = tickets.filter(t => t.id !== d.id);
        if (activeTicketId === d.id) showList();
        renderList();
    }

    if (d.type === 'notification') {
        showToast(d.message, d.style);
    }

    // Antwort-Banner oben Mitte
    if (d.type === 'showReply') {
        document.getElementById('reply-admin-name').textContent =
            '🛡️ Admin ' + d.data.adminName + ' – Ticket #' + d.data.ticketId;
        document.getElementById('reply-message').textContent = d.data.message;
        replyBanner.classList.add('visible');
        clearTimeout(replyTimer);
        replyTimer = setTimeout(() => replyBanner.classList.remove('visible'), 12000);
    }
});

// ── Ticket senden ────────────────────────────────────
function sendTicket() {
    const msg = document.getElementById('ticket-message').value.trim();
    if (!msg || msg.length < 5) {
        showToast('Bitte beschreibe dein Problem (min. 5 Zeichen)!', 'error');
        return;
    }
    fetch('https://esx_ticket/sendTicket', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: msg })
    });
    closeAll();
}

// ── Char Counter ──────────────────────────────────────
function updateCharCount() {
    const ta = document.getElementById('ticket-message');
    const cc = document.getElementById('char-count');
    if (!ta || !cc) return;
    ta.addEventListener('input', function() {
        cc.textContent = this.value.length + ' / 500';
        cc.style.color = this.value.length > 450 ? '#f87171' : 'rgba(255,255,255,0.25)';
    });
}
updateCharCount();

// ── Liste rendern ─────────────────────────────────────
function renderList() {
    // Alle Cards entfernen außer empty-state
    const cards = ticketList.querySelectorAll('.ticket-card');
    cards.forEach(c => c.remove());

    const open = tickets.filter(t => !t.resolved);
    countBadge.textContent = open.length + ' offen';
    emptyState.style.display = open.length === 0 ? 'flex' : 'none';

    open.forEach(t => {
        const card = document.createElement('div');
        card.className = 'ticket-card' + (t.claimed ? ' claimed' : '');
        card.dataset.id = t.id;
        card.innerHTML = `
            <div class="ticket-num">#${t.id}</div>
            <div class="ticket-card-info">
                <div class="ticket-card-name">${esc(t.playerName)}</div>
                <div class="ticket-card-msg">${esc(t.message)}</div>
            </div>
            <span class="ticket-badge ${t.claimed ? 'badge-claimed' : 'badge-open'}">
                ${t.claimed ? '✋ ' + esc(t.claimedName) : '🔴 Offen'}
            </span>
            <div class="ticket-time">${esc(t.time)}</div>
        `;
        card.addEventListener('click', () => openDetail(t.id));
        ticketList.appendChild(card);
    });
}

// ── Detail öffnen ─────────────────────────────────────
function openDetail(id) {
    const t = tickets.find(t => t.id === id);
    if (!t) return;
    activeTicketId = id;
    renderDetail(t);
    ticketList.classList.add('hidden');
    ticketDetail.classList.remove('hidden');
}

function renderDetail(t) {
    document.getElementById('detail-id').textContent = t.id;
    document.getElementById('detail-player').textContent = t.playerName;
    document.getElementById('detail-time').textContent = t.time;
    document.getElementById('detail-message').textContent = t.message;

    const statusEl = document.getElementById('detail-status');
    if (t.claimed) {
        statusEl.textContent = '✋ Geclaimed';
        statusEl.style.cssText = 'background:rgba(251,191,36,0.15);border:1px solid rgba(251,191,36,0.3);color:#fbbf24;';
    } else {
        statusEl.textContent = '🔴 Offen';
        statusEl.style.cssText = 'background:rgba(239,68,68,0.15);border:1px solid rgba(239,68,68,0.3);color:#f87171;';
    }

    const claimedRow = document.getElementById('detail-claimed-row');
    if (t.claimed && t.claimedName) {
        document.getElementById('detail-claimed-name').textContent = t.claimedName;
        claimedRow.style.display = 'flex';
    } else {
        claimedRow.style.display = 'none';
    }

    document.getElementById('btn-claim').style.display = t.claimed ? 'none' : '';
    document.getElementById('btn-tp').style.display    = t.claimed ? ''     : 'none';
}

// ── Zurück zur Liste ──────────────────────────────────
function showList() {
    activeTicketId = null;
    ticketList.classList.remove('hidden');
    ticketDetail.classList.add('hidden');
}

// ── Aktionen ──────────────────────────────────────────
function claimTicket() {
    if (!activeTicketId) return;
    fetch('https://esx_ticket/claimTicket', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: activeTicketId })
    });
    showToast('Ticket geclaimed – teleportiere...', 'info');
}

function tpTicket() {
    if (!activeTicketId) return;
    fetch('https://esx_ticket/teleportTicket', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: activeTicketId })
    });
    showToast('Teleportiere zum Spieler...', 'info');
}

function sendReply() {
    if (!activeTicketId) return;
    const msg = document.getElementById('reply-input').value.trim();
    if (!msg) { showToast('Bitte eine Antwort eingeben!', 'error'); return; }
    fetch('https://esx_ticket/replyTicket', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: activeTicketId, message: msg })
    });
    document.getElementById('reply-input').value = '';
}

function deleteTicket() {
    if (!activeTicketId) return;
    fetch('https://esx_ticket/deleteTicket', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: activeTicketId })
    });
    showList();
}

// ── Schließen ─────────────────────────────────────────
function closeAll() {
    fetch('https://esx_ticket/close', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
    });
    overlay.classList.remove('visible');
    playerPanel.classList.add('hidden');
    adminPanel.classList.add('hidden');
}

function closeReply() {
    replyBanner.classList.remove('visible');
    clearTimeout(replyTimer);
}

// ── Toast ─────────────────────────────────────────────
function showToast(msg, style) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.className = 'show ' + (style || 'info');
    clearTimeout(window._tt);
    window._tt = setTimeout(() => { t.className = ''; }, 3500);
}

// ── ESC ───────────────────────────────────────────────
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeAll();
});

// ── Helper ────────────────────────────────────────────
function esc(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g,'&amp;')
        .replace(/</g,'&lt;')
        .replace(/>/g,'&gt;')
        .replace(/"/g,'&quot;');
}
