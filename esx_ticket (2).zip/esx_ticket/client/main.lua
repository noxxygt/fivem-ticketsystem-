-- ====================================================
--  esx_ticket | client/main.lua
-- ====================================================

local menuOpen   = false
local replyTimer = nil

-- ── /ticket → Ticket-Formular öffnen ────────────────
RegisterCommand('ticket', function()
    if menuOpen then return end
    menuOpen = true
    SetNuiFocus(true, true)
    SendNUIMessage({ type = 'openPlayer' })
end, false)

-- ── /tickets → Admin-Panel öffnen ───────────────────
RegisterCommand('tickets', function()
    if menuOpen then return end
    TriggerServerEvent('esx_ticket:requestAll')
end, false)

-- ── Server: Alle Tickets laden (Admin) ───────────────
RegisterNetEvent('esx_ticket:loadAll')
AddEventHandler('esx_ticket:loadAll', function(data)
    menuOpen = true
    SetNuiFocus(true, true)
    SendNUIMessage({ type = 'openAdmin', tickets = data })
end)

-- ── Neues Ticket → Admin Panel updaten ──────────────
RegisterNetEvent('esx_ticket:newTicket')
AddEventHandler('esx_ticket:newTicket', function(ticket)
    SendNUIMessage({ type = 'newTicket', ticket = ticket })
    -- Ton / Popup Hinweis
    BeginTextCommandThefeedPost('STRING')
    AddTextComponentSubstringPlayerName('~r~[TICKET] ~w~Neues Ticket #' .. ticket.id .. ' von ~y~' .. ticket.playerName)
    EndTextCommandThefeedPostTicker(false, true)
end)

-- ── Ticket Update → Admin Panel ──────────────────────
RegisterNetEvent('esx_ticket:updateTicket')
AddEventHandler('esx_ticket:updateTicket', function(ticket)
    SendNUIMessage({ type = 'updateTicket', ticket = ticket })
end)

-- ── Ticket entfernen → Admin Panel ──────────────────
RegisterNetEvent('esx_ticket:removeTicket')
AddEventHandler('esx_ticket:removeTicket', function(id)
    SendNUIMessage({ type = 'removeTicket', id = id })
end)

-- ── Teleport zu Spieler-Koordinaten ─────────────────
RegisterNetEvent('esx_ticket:teleport')
AddEventHandler('esx_ticket:teleport', function(coords)
    local ped = PlayerPedId()
    SetEntityCoords(ped, coords.x, coords.y, coords.z + 1.0, false, false, false, true)
    BeginTextCommandThefeedPost('STRING')
    AddTextComponentSubstringPlayerName('~b~[TICKET] ~w~Zum Spieler teleportiert')
    EndTextCommandThefeedPostTicker(false, true)
end)

-- ── Notification ─────────────────────────────────────
RegisterNetEvent('esx_ticket:notification')
AddEventHandler('esx_ticket:notification', function(msg, style)
    SendNUIMessage({ type = 'notification', message = msg, style = style })
end)

-- ── Admin-Antwort → Spieler oben in der Mitte ───────
RegisterNetEvent('esx_ticket:showReply')
AddEventHandler('esx_ticket:showReply', function(data)
    SendNUIMessage({ type = 'showReply', data = data })
end)

-- ── NUI Callbacks ────────────────────────────────────

-- Ticket senden
RegisterNUICallback('sendTicket', function(data, cb)
    TriggerServerEvent('esx_ticket:create', data.message)
    menuOpen = false
    SetNuiFocus(false, false)
    cb({})
end)

-- Schließen
RegisterNUICallback('close', function(_, cb)
    menuOpen = false
    SetNuiFocus(false, false)
    cb({})
end)

-- Claimen
RegisterNUICallback('claimTicket', function(data, cb)
    TriggerServerEvent('esx_ticket:claim', data.id)
    cb({})
end)

-- TP
RegisterNUICallback('teleportTicket', function(data, cb)
    TriggerServerEvent('esx_ticket:teleportTo', data.id)
    cb({})
end)

-- Antwort senden
RegisterNUICallback('replyTicket', function(data, cb)
    TriggerServerEvent('esx_ticket:reply', data.id, data.message)
    cb({})
end)

-- Löschen
RegisterNUICallback('deleteTicket', function(data, cb)
    TriggerServerEvent('esx_ticket:delete', data.id)
    cb({})
end)
