-- ====================================================
--  esx_ticket | server/main.lua
-- ====================================================

ESX = exports['es_extended']:getSharedObject()

-- Aktive Tickets { id, playerId, playerName, message, claimed, claimedBy, coords, time }
local tickets   = {}
local ticketId  = 0

-- Admin Gruppen die Tickets sehen/bearbeiten duerfen
local adminGroups = { 'admin', 'superadmin', 'moderator', 'mod' }

local function isAdmin(source)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return false end
    local group = xPlayer.getGroup()
    for _, g in ipairs(adminGroups) do
        if group == g then return true end
    end
    return false
end

local function broadcastToAdmins(event, data)
    for _, src in ipairs(GetPlayers()) do
        local id = tonumber(src)
        if isAdmin(id) then
            TriggerClientEvent(event, id, data)
        end
    end
end

-- ── Ticket erstellen ─────────────────────────────────
RegisterNetEvent('esx_ticket:create')
AddEventHandler('esx_ticket:create', function(message)
    local src     = source
    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer then return end

    -- Max 1 offenes Ticket pro Spieler
    for _, t in ipairs(tickets) do
        if t.playerId == src and not t.resolved then
            TriggerClientEvent('esx_ticket:notification', src, 'Du hast bereits ein offenes Ticket!', 'error')
            return
        end
    end

    ticketId = ticketId + 1
    local coords = GetEntityCoords(GetPlayerPed(src))

    local ticket = {
        id         = ticketId,
        playerId   = src,
        playerName = xPlayer.getName(),
        message    = message,
        claimed    = false,
        claimedBy  = nil,
        claimedName= nil,
        resolved   = false,
        coords     = { x = coords.x, y = coords.y, z = coords.z },
        time       = os.date('%H:%M:%S')
    }

    table.insert(tickets, ticket)

    -- Bestätigung an Spieler
    TriggerClientEvent('esx_ticket:notification', src, 'Dein Ticket #' .. ticketId .. ' wurde gesendet!', 'success')

    -- Alle Admins benachrichtigen
    broadcastToAdmins('esx_ticket:newTicket', ticket)
end)

-- ── Ticket claimen ───────────────────────────────────
RegisterNetEvent('esx_ticket:claim')
AddEventHandler('esx_ticket:claim', function(id)
    local src = source
    if not isAdmin(src) then return end

    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer then return end

    for _, t in ipairs(tickets) do
        if t.id == id and not t.claimed then
            t.claimed     = true
            t.claimedBy   = src
            t.claimedName = xPlayer.getName()

            -- Admin bekommt TP-Koordinaten
            TriggerClientEvent('esx_ticket:teleport', src, t.coords)

            -- Spieler informieren
            if GetPlayerPing(t.playerId) > 0 then
                TriggerClientEvent('esx_ticket:notification', t.playerId,
                    'Dein Ticket wird von ' .. xPlayer.getName() .. ' bearbeitet!', 'info')
            end

            -- Alle Admins updaten
            broadcastToAdmins('esx_ticket:updateTicket', t)
            return
        end
    end
end)

-- ── Ticket TP (nochmal) ──────────────────────────────
RegisterNetEvent('esx_ticket:teleportTo')
AddEventHandler('esx_ticket:teleportTo', function(id)
    local src = source
    if not isAdmin(src) then return end

    for _, t in ipairs(tickets) do
        if t.id == id then
            TriggerClientEvent('esx_ticket:teleport', src, t.coords)
            return
        end
    end
end)

-- ── Ticket antworten ─────────────────────────────────
RegisterNetEvent('esx_ticket:reply')
AddEventHandler('esx_ticket:reply', function(id, replyMsg)
    local src = source
    if not isAdmin(src) then return end

    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer then return end

    for _, t in ipairs(tickets) do
        if t.id == id then
            if GetPlayerPing(t.playerId) > 0 then
                TriggerClientEvent('esx_ticket:showReply', t.playerId, {
                    adminName = xPlayer.getName(),
                    message   = replyMsg,
                    ticketId  = id
                })
            end
            TriggerClientEvent('esx_ticket:notification', src, 'Antwort an ' .. t.playerName .. ' gesendet!', 'success')
            return
        end
    end
end)

-- ── Ticket löschen ───────────────────────────────────
RegisterNetEvent('esx_ticket:delete')
AddEventHandler('esx_ticket:delete', function(id)
    local src = source
    if not isAdmin(src) then return end

    for i, t in ipairs(tickets) do
        if t.id == id then
            -- Spieler informieren falls online
            if GetPlayerPing(t.playerId) > 0 then
                TriggerClientEvent('esx_ticket:notification', t.playerId,
                    'Dein Ticket #' .. id .. ' wurde geschlossen.', 'info')
            end
            table.remove(tickets, i)
            broadcastToAdmins('esx_ticket:removeTicket', id)
            return
        end
    end
end)

-- ── Admin öffnet Ticket-Panel → alle Tickets senden ──
RegisterNetEvent('esx_ticket:requestAll')
AddEventHandler('esx_ticket:requestAll', function()
    local src = source
    if not isAdmin(src) then
        TriggerClientEvent('esx_ticket:notification', src, 'Keine Berechtigung!', 'error')
        return
    end
    TriggerClientEvent('esx_ticket:loadAll', src, tickets)
end)
