fx_version 'cerulean'
game 'gta5'

name        'esx_ticket'
description 'Report/Ticket System mit NUI fuer Spieler und Admins'
author      'Custom'
version     '1.0.0'

client_scripts {
    'client/main.lua'
}

server_scripts {
    '@es_extended/imports.lua',
    'server/main.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/css/style.css',
    'html/js/app.js'
}

dependencies {
    'es_extended'
}
